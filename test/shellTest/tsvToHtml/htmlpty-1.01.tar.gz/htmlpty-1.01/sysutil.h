#if !defined(SYSUTIL_H)
#define SYSUTIL_H 1

const char *	email_address ARGS((void));
const char *	host_name ARGS((void));
const char *	login_name ARGS((void));
const char *	personal_name ARGS((void));

#endif /* defined(SYSUTIL_H) */
